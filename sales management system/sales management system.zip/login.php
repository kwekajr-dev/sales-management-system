
<!DOCTYPE html>
<html lang="en">
<head>
    <title>#oGTech company</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
<div class="call">
        <center>
    <h2 style="background-color: white; width:190px;border-radius:15px;color:blue;">OGTECH  LOGIN</h2>
        </center>
    </div>
    <div class="box">
        <form method="POST">
            <div>
                <label for="Email">Email</label><br>
                <input type="Email" id="Email" name="Email" class="small" >
            </div>
            <div>
                <label for="password">Password</label><br>
                <input type="password" id="password" name="password" class="small" >
            </div>
            <button type="submit">Login</button>
            <p>Don't you have account? <a href="register.php">Sign up</a></p>
        </form>
    </div>
    </div>
    
    
</body>
</html>
